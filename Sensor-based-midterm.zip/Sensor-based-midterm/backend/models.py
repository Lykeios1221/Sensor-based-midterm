from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, DateTime, Float
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()
class EnvironmentData(Base):
    __tablename__ = 'environment_data'

    id = Column(Integer, primary_key=True, autoincrement=True)
    datetime = Column(DateTime, nullable=False)
    humidity = Column(Float, nullable=False)
    temperature = Column(Float, nullable=False)
    heatIndex = Column(Float, nullable=False)
    air_data = relationship("AirDta", back_populates="environment_data", cascade="all, delete-orphan")

class AirDta(Base):
    __tablename__ = 'air_dta'

    id = Column(Integer, primary_key=True, autoincrement=True)
    co = Column(Float, nullable=False)
    alcohol = Column(Float, nullable=False)
    co2 = Column(Float, nullable=False)
    toluene = Column(Float, nullable=False)
    nh4 = Column(Float, nullable=False)
    acetone = Column(Float, nullable=False)
    envKey = Column(Integer, ForeignKey('environment_data.id', ondelete='CASCADE', onupdate='CASCADE'), nullable=False)
    environment_data = relationship("EnvironmentData", back_populates="air_data")
