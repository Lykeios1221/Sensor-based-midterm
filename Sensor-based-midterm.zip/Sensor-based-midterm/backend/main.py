import asyncio
import json
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any

from fastapi import FastAPI, WebSocket
from fastapi.encoders import jsonable_encoder
from fastapi.middleware.cors import CORSMiddleware
from fastapi_async_sqlalchemy import SQLAlchemyMiddleware
from fastapi_async_sqlalchemy import db
from fastapi_mqtt import FastMQTT, MQTTConfig
from gmqtt import Client as MQTTClient
from sqlalchemy import URL, select
from sqlalchemy.orm import joinedload
from starlette.responses import JSONResponse
from starlette.websockets import WebSocketDisconnect

from models import EnvironmentData, AirDta

mqtt_config = MQTTConfig(host="192.168.72.202")
fast_mqtt = FastMQTT(config=mqtt_config)

sendingEntry = False
message_queue = asyncio.Queue()


app = FastAPI()

@app.on_event("startup")
async def startup_event():
    await fast_mqtt.mqtt_startup()
    print("MQTT connection started")


origins = ["http://localhost", "http://localhost:3000", "http://localhost:5173"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    SQLAlchemyMiddleware,
    db_url=URL.create(
        "mysql+asyncmy",
        username="root",
        password="",
        host="localhost",
        database="sensor_based_midterm",
    ),
    engine_args={  # engine arguments example
        "echo": True,  # print all SQL statements
        "pool_pre_ping": True,
        # feature will normally emit SQL equivalent to “SELECT 1” each time a connection is checked out from the pool
        "pool_size": 5,  # number of connections to keep open at a time
        "max_overflow": 10,  # number of connections to allow to be opened above pool_size
    },
)


@fast_mqtt.on_connect()
def connect(client: MQTTClient, flags: int, rc: int, properties: Any):
    client.subscribe("esp32/envData/out")  # subscribing mqtt topic
    print("Connected: ", client, flags, rc, properties)


@fast_mqtt.subscribe("esp32/envData/out", qos=0)
async def handle_mqtt_message(
        client: MQTTClient, topic: str, payload: bytes, qos: int, properties: Any
):
    message = payload.decode()
    data = json.loads(message)
    gasPPM = data["gasPPM"]
    async with db() as session:
        try:
            new_environment_data = EnvironmentData(
                datetime=datetime.fromisoformat(data["datetime"]),
                humidity=data["humidity"],
                temperature=data["temperature"],
                heatIndex=data["heatIndex"],
            )
            session.session.add(new_environment_data)
            await session.session.commit()
            await session.session.refresh(new_environment_data)

            new_air_dta = AirDta(
                co=gasPPM["co"],
                alcohol=gasPPM["alcohol"],
                co2=gasPPM["co2"],
                toluene=gasPPM["toluene"],
                nh4=gasPPM["nh4"],
                acetone=gasPPM["acetone"],
                envKey=new_environment_data.id,
            )
            session.session.add(new_air_dta)
            await session.session.commit()
            print("Data is successfully saved to database.")
        except Exception as e:
            print(f"Error inserting data: {e}")
            await session.session.rollback()
    await message_queue.put(message)
    print("New message added to queue.")


@app.get("/all_data")
async def get_all_data():
    async with db() as session:
        try:
            result = await session.session.execute(
                select(EnvironmentData).options(joinedload(EnvironmentData.air_data))
            )
            all_data = result.unique().scalars().all()
            response = []
            for env_data in all_data:
                gasPPM = {
                    "co": env_data.air_data[0].co,
                    "alcohol": env_data.air_data[0].alcohol,
                    "co2": env_data.air_data[0].co2,
                    "toluene": env_data.air_data[0].toluene,
                    "nh4": env_data.air_data[0].nh4,
                    "acetone": env_data.air_data[0].acetone,
                }
                response.append(
                    {
                        "datetime": env_data.datetime.isoformat(),
                        "humidity": env_data.humidity,
                        "temperature": env_data.temperature,
                        "heatIndex": env_data.heatIndex,
                        "gasPPM": gasPPM,
                    }
                )
            return JSONResponse(content=jsonable_encoder(response))
        except Exception as e:
            print(f"Error retrieving data: {e}")
            return {"error": str(e)}


@fast_mqtt.on_disconnect()
def disconnect(client: MQTTClient, packet, exc=None):
    print("Disconnected")


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    global sendingEntry

    await websocket.accept()

    try:
        while True:
            if not message_queue.empty():
                try:
                    message = await message_queue.get()
                    await websocket.send_text(message)
                    print("Message sent to WebSocket client.")
                except asyncio.QueueEmpty:
                    await asyncio.sleep(1)  # Wait briefly if queue is empty
                except WebSocketDisconnect:
                    break  # Exit loop on WebSocket disconnect
            else:
                await asyncio.sleep(1)  # Wait briefly if not sending

    except WebSocketDisconnect:
        print("WebSocket disconnected")
    finally:
        sendingEntry = False