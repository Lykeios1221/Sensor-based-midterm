import React, { useEffect, useState } from 'react';
import '@carbon/charts-react/styles.css';
import useWebSocket from 'react-use-websocket';
import { RotateLoader } from 'react-spinners';
import { Card, CardBody, CardHeader, Col, Container, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { GaugeChart, LineChart } from '@carbon/charts-react';

const App = () => {
  const [data, setData] = useState(null);
  const [initialZoomDomain, setInitialZoomDomain] = useState([]);

  const { sendMessage, lastMessage, readyState } = useWebSocket(
    'ws://localhost:8000/ws',
    {
      onOpen: () => {
        console.log('WebSocket connection opened');
      },
      onMessage: (event) => {
        console.log('Received WebSocket message:', event.data);
        // Update data based on the message received from WebSocket
        const newMessage = JSON.parse(event.data);
        console.log('New data entry: ' + newMessage);
        setData((prevData) => {
          const updatedData = [...prevData, newMessage];
          updateZoomDomain(updatedData);
          return updatedData;
        });
      },
      onClose: () => console.log('WebSocket connection closed'),
      shouldReconnect: (closeEvent) => true, // Automatically reconnect on disconnect
    },
  );

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch('http://localhost:8000/all_data');
      const jsonData = await response.json();
      setData(jsonData);
      updateZoomDomain(jsonData);
      console.log('Initial data: ' + jsonData);
      sendMessage('init');
    };

    fetchData();
  }, []);


  const updateZoomDomain = (data) => {
    if (data && data.length > 0) {
      const datetimeObjects = data.map(d => new Date(d.datetime));
      const minDatetime = new Date(Math.min(...datetimeObjects));
      const maxDatetime = new Date(Math.max(...datetimeObjects));
      setInitialZoomDomain([minDatetime.toISOString(), maxDatetime.toISOString()]);
    }
  };

  return (
    <>
      {data === null && (
        <div className="d-flex h-100 justify-content-center">
          <RotateLoader
            className="align-self-center"
            color="#36d7b7"
          />
        </div>
      )}
      {data !== null && (
        <Container className="my-4">
          <Row className="row-gap-4">
            <Col className="col-12">
              <Card className="shadow">
                <Card.Header>Environment Data</Card.Header>
                <Card.Body>
                  <Row className="row-gap-md-3">
                    <Col md={12} lg={6}>
                      <Card><CardBody className="m-3"><LineChart
                        data={data.map((entry) => {
                          return { group: 'Humidity', date: entry.datetime, value: entry.humidity };
                        })}
                        options={{
                          title: 'Humidity Over Time',
                          axes: {
                            left: {},
                            bottom: {
                              scaleType: 'time',
                            },
                          },
                          color: {
                            pairing: {
                              option: 2, // use the second color palette option for 2-group charts
                            },
                          },
                          zoomBar: {
                            top: {
                              enabled: true,
                              initialZoomDomain: initialZoomDomain,
                            },
                          },
                        }}
                      ></ LineChart></CardBody>
                      </Card>
                    </Col>
                    <Col md={12} lg={6}>
                      <Card><CardBody className="m-3"><LineChart
                        data={data.map((entry) => {
                          return { group: 'Temperature', date: entry.datetime, value: entry.temperature };
                        })}
                        options={{
                          title: 'Temperature Over Time',
                          axes: {
                            left: {},
                            bottom: {
                              scaleType: 'time',
                            },
                          },
                          color: {
                            scale: {
                              'Temperature': 'orange',
                            },
                          },
                          zoomBar: {
                            top: {
                              enabled: true,
                              initialZoomDomain: initialZoomDomain,
                            },
                          },
                        }}
                      ></ LineChart></CardBody>
                      </Card>
                    </Col>
                    <Col className="col-12">
                      <Card><CardBody className="m-3"><LineChart
                        data={data.map((entry) => {
                          return { group: 'Heat Index', date: entry.datetime, value: entry.heatIndex };
                        })}
                        options={{
                          title: 'Heat Index Over Time',
                          axes: {
                            left: {},
                            bottom: {
                              scaleType: 'time',
                            },
                          },
                          color: {
                            scale: {
                              'Heat Index': 'red',
                            },
                          },
                          zoomBar: {
                            top: {
                              enabled: true,
                              initialZoomDomain: initialZoomDomain,
                            },
                          },
                        }}
                      ></ LineChart></CardBody>
                      </Card>
                    </Col>
                  </Row>
                </Card.Body>
              </Card>
            </Col>
            <Col className="col-12">
              <Card className="shadow">
                <CardHeader>
                  Air Data
                </CardHeader>
                <CardBody>
                  <Row className="row-gap-md-4">
                    <Col lg={8} md={12}><Card><CardBody className="m-3"><LineChart
                      data={[
                        ...data.map((entry) => ({
                          group: 'CO',
                          date: entry.datetime,
                          value: entry.gasPPM.co,
                        })),
                        ...data.map((entry) => ({
                          group: 'Alcohol',
                          date: entry.datetime,
                          value: entry.gasPPM.alcohol,
                        })),
                        ...data.map((entry) => ({
                          group: 'Toluene',
                          date: entry.datetime,
                          value: entry.gasPPM.toluene,
                        })),
                        ...data.map((entry) => ({
                          group: 'NH4',
                          date: entry.datetime,
                          value: entry.gasPPM.nh4,
                        })),
                        ...data.map((entry) => ({
                          group: 'Acetone',
                          date: entry.datetime,
                          value: entry.gasPPM.acetone,
                        })),
                      ]}
                      options={{
                        title: 'Gas PPM Over Time',
                        axes: {
                          left: {},
                          bottom: {
                            scaleType: 'time',
                          },
                        },
                        zoomBar: {
                          top: {
                            enabled: true,
                            initialZoomDomain: initialZoomDomain,
                          },
                        },
                        color: {
                          scale: {
                            'CO': '#d62728', // Red
                            'Alcohol': '#9467bd', // Purple
                            'Toluene': '#8c564b', // Brown
                            'NH4': '#e377c2', // Pink
                            'Acetone': '#7f7f7f', // Gray
                          },
                        },
                      }}
                    ></ LineChart></CardBody></Card></Col>
                    <Col lg={4} md={12}>
                      <Card><CardBody className="m-3"><GaugeChart
                        data={[
                          {
                            group: 'value',
                            value: data[data.length - 1].gasPPM.co2, // Assuming CO2 is the last data point
                          },
                          {
                            group: 'delta',
                            value: (data[data.length - 1].gasPPM.co2 - data[data.length - 2].gasPPM.co2) / data[data.length - 2].gasPPM.co2 * 100,
                          },
                        ]}
                        options={{
                          title: 'CO2 Gauge Chart',
                          resizable: true,
                          height: '400px',
                          width: '100%',
                          gauge: {
                            type: 'semi',
                            status: 'danger',
                            showPercentageSymbol: false,
                          },
                        }}
                      ></ GaugeChart></CardBody>
                      </Card>
                    </Col>
                  </Row>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      )}
    </>
  );
};

export default App;
