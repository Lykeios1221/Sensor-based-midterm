#include <Arduino.h>
#include <RTClib.h>
#include <DHTesp.h>
#include <MQUnifiedsensor.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

const ulong SAMPLING_INTERVAL_MS = 5000;
ulong previousMillis, currentMillis;

// Setup for real time clock
RTC_DS3231 rtc;
const DateTime RTC_FORMAT = DateTime(F(__DATE__), F(__TIME__));
const char *DATETIME_FORMAT = "%02d-%02d-%02dT%02d:%02d:%02d";
char timeString[20];

//Setup for DHT11
DHTesp dht;
const uint8_t DHT_PIN = 33;

//Setup for MQ135
const uint8_t MQ_PIN = 34; // Use ADC-1 to avoid network issue
const char *BOARD = "ESP-32";
const char *MQ_TYPE = "MQ-135";
const uint8_t ADC_BIT_RESOLUTION = 12;
const float VOLTAGE_RESOLUTION = 3.3;
const float RATIO_MQ135_CLEAN_AIR = 3.6;
const float ATMOSPHERE_CO2_OFFSET = 421; // current global average concentration of carbon dioxide (CO2) in the atmosphere
MQUnifiedsensor MQ135(BOARD, VOLTAGE_RESOLUTION, ADC_BIT_RESOLUTION, MQ_PIN, MQ_TYPE);
// Below values from GitHub, not sure what it meant, probably gas-related domain knowledge
/*
  Exponential regression:
GAS      | a      | b
CO       | 605.18 | -3.937
Alcohol  | 77.255 | -3.18
CO2      | 110.47 | -2.862
Toluen   | 44.947 | -3.445
NH4      | 102.2  | -2.473
Aceton   | 34.668 | -3.369
*/
enum GasType {
    CO,
    ALCHOHOL,
    CO2,
    TOLUENE,
    NH4,
    ACETON,
    NUM_GASES // This will be used to define the size of the array
};
const float MQRegressionFactors[NUM_GASES][2] = {
        {605.18, -3.937},
        {77.255 , -3.18},
        {110.47 , -2.862},
        {44.947 , -3.445},
        {102.2  , -2.473},
        {34.668 , -3.369},
};

// Parameters to model temperature and humidity dependence
const float CORA = 0.00035;
const float CORB = 0.02718;
const float CORC = 1.39538;
const float CORD = .0018;

// WiFi setup
const char* ssid = "OnePlus 8";
const char* password = "derrick123";
WiFiClient espClient;

// MQTT setup
IPAddress mqtt_server(192, 168, 72, 202);
PubSubClient client(espClient);
const char* MQTT_TOPIC = "esp32/envData/out";
const char* MQTT_ID = "ESP32CLIENT";
JsonDocument mqttMessageJson;
enum mqtt_status {
    MESSAGE_PENDING,
    MESSAGE_SUCCESS,
} status = MESSAGE_PENDING;

void initMQ135() {
    MQ135.setRegressionMethod(1); //_PPM =  a*ratio^b
    MQ135.setA(MQRegressionFactors[CO2][0]);
    MQ135.setB(MQRegressionFactors[CO2][1]);
    MQ135.init();

    Serial.print("Calibrating please wait.");
    float calcR0 = 0;
    for (int i = 1; i <= 10; i++) {
        MQ135.update(); // Update data, the arduino will read the voltage from the analog pin
        calcR0 += MQ135.calibrate(RATIO_MQ135_CLEAN_AIR);
        Serial.print(".");
    }
    MQ135.setR0(calcR0 / 10);
    Serial.println("  done!.\n");
    if (isinf(calcR0)) {
        Serial.println(
                "Warning: Conection issue, R0 is infinite (Open circuit detected) please check your wiring and supply");
        esp_deep_sleep_start();
    }
    if (calcR0 == 0) {
        Serial.println(
                "Warning: Conection issue found, R0 is zero (Analog pin shorts to ground) please check your wiring and supply");
        esp_deep_sleep_start();
    }
}

void mqttCallback(char* topic, byte* message, unsigned int length) {
    status = MESSAGE_SUCCESS;
}

void setup() {
    Serial.begin(115200);
    while (!Serial);
    Serial.println("\n\nSerial monitor is ready");

    Serial.println("\nAttempting to connect network...");
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password);
    if (WiFi.waitForConnectResult(60000) != WL_CONNECTED) {
        Serial.println("Network connection failed.");
        esp_deep_sleep_start();
    }
    Serial.println("Network has been connected successfully");

    // Initialize RTC
    if (!rtc.begin()) {
        Serial.println("\nRTC module initialization failed.");
        esp_deep_sleep_start();
    }

    // Adjust time based on the format with info obtained from usb connected device
    rtc.adjust(RTC_FORMAT);
    Serial.println("\nRTC clock has been initialized successfully.");

    dht.setup(DHT_PIN, DHTesp::DHT11);
    Serial.println("\nDHT has been initialized successfully.");

    Serial.println("\nInitializing MQ135");
    initMQ135();
    Serial.println("MQ135 has been initialized successfully.");

    client.setServer(mqtt_server, 1883);
    client.setCallback(mqttCallback);

    Serial.println("\n\nESP has been fully setup.\n\n");
}

float getCorrectionFactor(float t, float h) {
    return CORA * t * t - CORB * t + CORC - (h-33.)*CORD;
}


float getGasPPM(GasType type, float temperature, float humidity, float cFactor) {
    MQ135.setA(MQRegressionFactors[type][0]); MQ135.setB((MQRegressionFactors[type][1]));
    return MQ135.readSensor(false, cFactor);
}

bool reconnect() {
    // Loop until we're reconnected
    while (!client.connected()) {
        Serial.print("Attempting MQTT connection...");
        // Attempt to connect
        if (client.connect(MQTT_ID)) {
            Serial.println("connected");
            client.subscribe(MQTT_TOPIC);
            return true;
        } else {
            Serial.print("failed, rc=");
            Serial.print(client.state());
            Serial.println(" try again in 3 seconds");
            delay(3000);
            return false;
        }
    }
    return false;
}

void loop() {
    if (!client.connected()) {
        if (!reconnect()) {
            return;
        }
    }
    client.loop();

    if (status == MESSAGE_SUCCESS) {
        Serial.print(" Message arrived on topic: ");
        Serial.println(MQTT_TOPIC);
        mqttMessageJson.clear();
        Serial.println();
        status = MESSAGE_PENDING;
    } else if (status != MESSAGE_PENDING) {
        Serial.println(" Publishing of message failed.");
    }

    currentMillis = millis();
    if (currentMillis - previousMillis >= SAMPLING_INTERVAL_MS) {
        previousMillis = currentMillis;
        DateTime currentDateTime = rtc.now();
        sprintf(timeString,
                DATETIME_FORMAT,
                currentDateTime.year(),
                currentDateTime.month(),
                currentDateTime.day(),
                currentDateTime.hour(),
                currentDateTime.minute(),
                currentDateTime.second());

        float humidity = dht.getHumidity();
        float temperature = dht.getTemperature();

        // Validate DHT11 data, resampled immediately if failed
        if (!(isnormal(humidity) && isnormal(temperature))) {
            Serial.println("Failed to obtain valid environment data (humidity/temperature).");
            return;
        }

        MQ135.update();
        float gasPPM[NUM_GASES];
        const float cFactor = getCorrectionFactor(temperature, humidity);
        for (int i = 0; i < NUM_GASES; ++i) {
            const float ppm = getGasPPM(GasType(i), temperature, humidity, cFactor);
            if (isnan(ppm)) {
                Serial.println("Failed to obtain valid environment date (PPM type: " + String(i) + ").");
                return;
            }
            // The calibration will cause current state of the air assumed to be 0 PPM,
            // thus need add offset (recent PPM of CO2 present in the atmosphere)
            gasPPM[i] = GasType(i) == CO2 ? ppm + ATMOSPHERE_CO2_OFFSET : ppm;
        }

        float heatIndex = dht.computeHeatIndex(temperature, humidity);
        Serial.printf("------------------------------------> %s <------------------------------------\n"
                      "Cond >\tRelative humidity: %.2f \tTemperature: %.2f C \tHeat index: %.2f C\n"
                      "PPM >"
                      "\tCO: %.2f \tAlchohol: %.2f \tCO2: %.2f\n"
                      "\tToluene: %.2f \tNH4: %.2f \tAcetone: %.2f\n",
                      timeString,
                      humidity,
                      temperature,
                      heatIndex,
                      gasPPM[0],
                      gasPPM[1],
                      gasPPM[2],
                      gasPPM[3],
                      gasPPM[4],
                      gasPPM[5]
        );

        // Serialize to json
        mqttMessageJson["datetime"] = timeString;
        mqttMessageJson["humidity"] = humidity;
        mqttMessageJson["temperature"] = temperature;
        mqttMessageJson["heatIndex"] = heatIndex;
        JsonObject ppmDict = mqttMessageJson["gasPPM"].to<JsonObject>();
        ppmDict["co"] = gasPPM[0];
        ppmDict["alcohol"] = gasPPM[1];
        ppmDict["co2"] = gasPPM[2];
        ppmDict["toluene"] = gasPPM[3];
        ppmDict["nh4"] = gasPPM[4];
        ppmDict["acetone"] = gasPPM[5];
        String message;
        serializeJson(mqttMessageJson, message);
        Serial.print("Publishing message...");
        client.publish(MQTT_TOPIC, message.c_str());
    }
}